export class Customer {
    public  CustomerId:number;
    public firstName:string; 
	public	lastName:string ;
	public	emailId:string ;
	public	mobileNUmber:string ;
	public problem:string;
}
