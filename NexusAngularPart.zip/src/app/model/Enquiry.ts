export class Enquiry {
    public  eid:number;
    public name:string; 
	public	emailid:string ;
	public	mobilenumber:string ;
	public problem:string;
	public sector:string;
	public product:string;
	public closed:boolean;
	public refid:number;
	public status:string;
}
