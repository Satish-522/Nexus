import { Injectable } from '@angular/core';
import {Enquiry} from '../model/Enquiry';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import {Observable} from 'rxjs';
import {map} from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class Enquiryservice {
  baseUrl:string;
  constructor(private http:Http) {
   
    this.baseUrl="http://localhost:2525/Enquiry";
   }

   getAllEnquirys():Observable<Enquiry[]>{
     return this.http.get(this.baseUrl).pipe(
      map((data)=>data.json())
     );
   }
    getEnquiry(eid):Observable<Enquiry>{
     return this.http.get(this.baseUrl + "/" +eid).pipe(
      map((data)=>data.json()));
  //   );
  }
  deleteEnquiry(eid):Observable<Response>{
    return this.http.delete(this.baseUrl + "/" +eid);
  }

  getJsonContactTypeHeader():RequestOptions{
    const headers= new Headers();
    headers.append('Content-Type','application/json');
    return new RequestOptions({headers:headers}); // {key : value}
  }
  addEnquiry(Enquiry:Enquiry):Observable<Enquiry>{    // for communicating 
    let url=this.baseUrl;
    let content = JSON.stringify(Enquiry);//converting json to string
    let headers=this.getJsonContactTypeHeader();
    return this.http.post(url,content,headers).pipe( //post method gives updated Enquiry
      map(data=>data.json()));
    }

    updateEnquiry(Enquiry:Enquiry):Observable<Enquiry>{    // for telling that we are communicating
      let url=this.baseUrl;
      let content = JSON.stringify(Enquiry);//converting json to string
      let headers=this.getJsonContactTypeHeader();
      return this.http.put(url,content,headers).pipe( //put method gives updated Enquiry
        map(data=>data.json()));
      }


  }


