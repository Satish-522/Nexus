import { TestBed, inject } from '@angular/core/testing';

import { Enquiryservice } from './Enquiry.service';

describe('CustomerServiceService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [Enquiryservice]
    });
  });

  it('should be created', inject([Enquiryservice], (service: Enquiryservice) => {
    expect(service).toBeTruthy();
  }));
});
