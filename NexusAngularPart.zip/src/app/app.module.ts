import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {RouterModule,Routes, Route} from '@angular/router'
import { AppComponent } from './app.component';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';

import { TroubleshooterComponent } from './components/troubleshooter/troubleshooter.component';

import { EnquiryFormComponent } from './components/Enquiry-form/Enquiry-form.component';
import { SuccesspageComponent } from './components/successpage/successpage.component';
import { HomepageComponent } from './components/homepage/homepage.component';
import { StatuspageComponent } from './components/statuspage/statuspage.component';


const paths:Routes=[
    {path:'',component:HomepageComponent},
  
  {path:'formfiller',component:EnquiryFormComponent},
  {path:'success/:id',component:SuccesspageComponent},
  {path:'history',component:StatuspageComponent}

];

@NgModule({
  declarations: [
    AppComponent,
    TroubleshooterComponent,
    EnquiryFormComponent,
    SuccesspageComponent,
    HomepageComponent,
    StatuspageComponent
  

  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    RouterModule.forRoot(paths)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
