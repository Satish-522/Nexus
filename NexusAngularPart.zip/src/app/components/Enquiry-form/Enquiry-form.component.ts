import { Component, OnInit } from '@angular/core';
import {Enquiry} from '../../model/Enquiry';
import { Enquiryservice } from '../../service/Enquiry.service';
import { Router, ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-customer-form',
  templateUrl: './customer-form.component.html',
  styleUrls: ['./customer-form.component.css']
})
export class EnquiryFormComponent implements OnInit {
  Enquiry:Enquiry;
  
  dateToday:string;
  refid1:number;
  srchValue:number;
  constructor(private customerService: Enquiryservice,
    private router: Router,
    private activatedRoute: ActivatedRoute) { this.srchValue=0;}

  ngOnInit() {
    this.Enquiry = new Enquiry();
    this.dateToday= new Date().toDateString();
    
    
    // this.activatedRoute.params.subscribe(
    //   (params) => {
    //     let eid = params['id'];
    //     if (eid) {
          
    //       this.customerService.getEnquiry(eid).subscribe(
    //         (data) => this.Enquiry = data
    //       );
    //     }
    //   }
    // )
  }
  // saveCustomer() {
  //   if (this.isEdit) {
  //     this.customerService.updateCustomer(this.customer).subscribe(
  //       (data) => this.router.navigateByUrl("/")
  //     );
  //   } else {
  //     this.customerService.addCustomer(this.customer).subscribe(
  //       (data) => this.router.navigateByUrl("/")
  //     );
  //   }
  // }
  save(){
    
    this.Enquiry.closed=false;
    this.refid1=Math.trunc(Math.random()*100000000000);
    this.Enquiry.refid=this.refid1;
    this.Enquiry.status="0";
    this.customerService.addCustomer(this.Enquiry).subscribe(
      (data) => this.router.navigateByUrl("/success"+"/"+data.refid));
      // alert('We\'ll get back to you soon ,Thank you ');

  }
  // redirect(){
  //   this.customerService.getEnquiryByRefid(this.Enquiry).subscribe(
  //     (data) => this.router.navigateByUrl("/history"+"/"+data.refid));
  // }
  redirect(){
    this.router.navigate(["/history"],{queryParams:{srchValue:this.srchValue}});

  }
}
