import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-troubleshooter',
  templateUrl: './troubleshooter.component.html',
  styleUrls: ['./troubleshooter.component.css']
})
export class TroubleshooterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
