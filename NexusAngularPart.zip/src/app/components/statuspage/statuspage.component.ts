import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Enquiryservice } from '../../service/Enquiry.service';
import { Enquiry } from '../../model/Enquiry';
@Component({
  selector: 'app-statuspage',
  templateUrl: './statuspage.component.html',
  styleUrls: ['./statuspage.component.css']
})
export class StatuspageComponent implements OnInit {
  Enquiry: Enquiry[];
  statusid: number;


  constructor(private enquiryService: Enquiryservice,
    private activatedRoute: ActivatedRoute
  ) { }

  ngOnInit() {


    this.activatedRoute.queryParams.subscribe(
      (params) => {

        let srchValue = params['srchValue'];

        if (srchValue) {
          this.enquiryService.searchContacts(srchValue).subscribe(
            (data) => this.Enquiry = data
          );
        }

      }
    )
  }
}

