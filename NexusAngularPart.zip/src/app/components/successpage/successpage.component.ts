import { Component, OnInit } from '@angular/core';
import {Enquiry} from '../../model/Enquiry';
import { ActivatedRoute, Router } from '../../../../node_modules/@angular/router';
import { Enquiryservice} from '../../service/Enquiry.service';

@Component({
  selector: 'app-successpage',
  templateUrl: './successpage.component.html',
  styleUrls: ['./successpage.component.css']
})
export class SuccesspageComponent implements OnInit {
title:string;
refid:number;
Enquiry:Enquiry;


  constructor(private activatedRoute:ActivatedRoute,
  private Enquiryservice:Enquiryservice) {
    this.title="We\'ve got your report"
   }

  ngOnInit() {
    
    this.activatedRoute.params.subscribe(
      (params) => {
        this.refid = params['id'];
        if (this.refid) {
          
          this.Enquiryservice.getEnquiryByRefid(this.refid).subscribe(
            (data) => this.Enquiry= data
          );
          this.refid=this.Enquiry.refid;
        }
      }
    )
    
}
}

