package com.verizon.adb.model;

public enum Status {
	RECEIVED, PROCESSING , ADDRESSED
}
