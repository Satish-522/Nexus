package com.verizon.adb.model;

import java.time.LocalDate;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.UniqueElements;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;

@Entity
@Table(name = "Enquiry")
public class Enquiry {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long eid;

	public long getEid() {
		return eid;
	}

	public void setEid(long eid) {
		this.eid = eid;
	}
	
	
	@Column(name="refid")
	
	public long refid;


	public long getRefid() {
		return refid;
	}

	public void setRefid(long refid) {
		this.refid = refid;
	}


	@Column(name = "fnm")
	@NotNull
	private String Name;

	@NotNull(message = "email is required")
	@Email
	private String emailid;

	@NotEmpty(message = "cant be null")
	@Pattern(regexp = "\\d{10}", message = "you are in India remember")
	@Column(name = "mno")
	private String mobilenumber;

	@Column(name = "prob")
	private String problem;

	@Column(name = "Sector")
	private String sector;

	@Column(name = "product")
	private String product;
	
	@NotNull
	private boolean closed;
	
	@Column(name="status")
	private Status status;

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public String getEmailid() {
		return emailid;
	}

	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}

	public String getMobilenumber() {
		return mobilenumber;
	}

	public void setMobilenumber(String mobilenumber) {
		this.mobilenumber = mobilenumber;
	}

	public String getProblem() {
		return problem;
	}

	public void setProblem(String problem) {
		this.problem = problem;
	}

	public String getSector() {
		return sector;
	}

	public void setSector(String sector) {
		this.sector = sector;
	}

	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	public boolean isClosed() {
		return closed;
	}

	public void setClosed(boolean closed) {
		this.closed = closed;
	}

	public Enquiry() {
		super();
	}

	public Enquiry(long eid, long refid,  String name,
			@NotNull(message = "email is required") @Email String emailid,
			@NotEmpty(message = "cant be null") @Pattern(regexp = "\\d{10}", message = "you are in India remember") String mobilenumber,
			String problem, String sector, String product, @NotNull boolean closed, Status status) {
		super();
		this.eid = eid;
		this.refid = refid;
		this.Name = name;
		this.emailid = emailid;
		this.mobilenumber = mobilenumber;
		this.problem = problem;
		this.sector = sector;
		this.product = product;
		this.closed = closed;
		this.status = status;
	}

	
	

}
