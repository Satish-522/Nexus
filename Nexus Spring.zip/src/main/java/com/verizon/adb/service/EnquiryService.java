package com.verizon.adb.service;

import java.util.List;

import com.verizon.adb.model.Enquiry;

public interface EnquiryService {
	Enquiry getEnquiryById(long refid);
	List<Enquiry> getAllEnquiries();
	Enquiry addEnquiry(Enquiry enquiry);
//	Enquiry updateCustomer(Enquiry Customer);
//	boolean deleteCustomer(long CustomerId);
	

	
	
	Enquiry findByMobilenumber(String mobilenumber);
	Enquiry findByEmailid(String emailid);
//	List<Customer> findAllByLastName(String lastName);
	Enquiry findByRefid(long refid);
}
