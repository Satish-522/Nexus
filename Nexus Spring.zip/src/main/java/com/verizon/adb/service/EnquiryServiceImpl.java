package com.verizon.adb.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.verizon.adb.dao.EnquiryRepository;
import com.verizon.adb.model.Enquiry;

@Service 
public class EnquiryServiceImpl implements EnquiryService{
	
	@Autowired
	private EnquiryRepository EnquiryRepo;

	@Override
	public Enquiry getEnquiryById(long refid) {
		Enquiry enquiry=null;
//		if(EnquiryRepo.existsById(CustomerId)){  // Data base is hit twice while searching and retrieving
//			Customer= EnquiryRepo.findById(CustomerId).get();
//		}
		Optional<Enquiry> optCustomer=EnquiryRepo.findById(refid);
		if(optCustomer.isPresent()){// checking if data is available
			enquiry=optCustomer.get();// retrieve the data using .get
		}
		return enquiry;
	}

	@Override
	public List<Enquiry> getAllEnquiries() {
		return EnquiryRepo.findAll();
	}

	@Override
	public Enquiry addEnquiry(Enquiry enquiry) { // save func will check is data is there(then merge) else persist(add)
		return EnquiryRepo.save(enquiry);
	}

//	@Override
//	public Enquiry updateCustomer(Enquiry Customer) {
//		return EnquiryRepo.save(Customer);
//	}
//
//	@Override
//	public boolean deleteCustomer(long CustomerId) {
//		boolean isDeleted=false;
//	
//		if(EnquiryRepo.existsById(CustomerId)){
//		
//		EnquiryRepo.deleteById(CustomerId);
//		isDeleted=true;}
//		return isDeleted;
//	}

	

	@Override
	public Enquiry findByMobilenumber(String mobilenumber) {
		
		return EnquiryRepo.findByMobilenumber(mobilenumber);
	}

	@Override
	public Enquiry findByEmailid(String emailid) {
		
		return EnquiryRepo.findByEmailid(emailid);
	}

	@Override
	public Enquiry findByRefid(long refid) {
		
		return EnquiryRepo.findByRefid(refid);
	}

//	s

}
