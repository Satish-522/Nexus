package com.verizon.adb.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.verizon.adb.model.Enquiry;

@Repository //TO REGISTER THIS IN bean.xml
public interface EnquiryRepository extends JpaRepository<Enquiry,Long>{//Entity to be persisted, datatype
	

	
	Enquiry findByMobilenumber(String mobilenumber);
	Enquiry findByEmailid(String emailid);
//	List<Customer> findAllByLastName(String lastName);
	Enquiry findByRefid(long refid);
}
