package com.verizon.adb.restapi;

import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.verizon.adb.model.Enquiry;
import com.verizon.adb.service.EnquiryService;

@RestController
@CrossOrigin
@RequestMapping("/enquiry")
public class EnquiryApi {

	@Autowired
	private EnquiryService service;

	@GetMapping
	public ResponseEntity<List<Enquiry>> getAllEnquiries() {
		return new ResponseEntity<>(service.getAllEnquiries(), HttpStatus.OK);

	}

//	@GetMapping("/{refid}")
//	public ResponseEntity<Enquiry> getEnquiryById(@PathVariable("refid") long refid) {
//		ResponseEntity<Enquiry> resp;
//		Enquiry c = service.getEnquiryById(refid);
//		if (c == null)
//			resp = new ResponseEntity<>(HttpStatus.NOT_FOUND);
//		else
//			resp = new ResponseEntity<>(c, HttpStatus.OK);
//		return resp;
//
//	}
	@GetMapping("/{srchValue}")
	public ResponseEntity<List<Enquiry>> getAllEnquiries (
		
		@PathVariable("srchValue") long searchValue)
	{
		ResponseEntity<List<Enquiry>> resp = null;
			
			
				Enquiry cBYMobNum= service.findByRefid(searchValue);
				if(cBYMobNum!=null){
					resp=new ResponseEntity<>(Collections.singletonList(cBYMobNum),HttpStatus.OK);}
				else {
					resp=new ResponseEntity<>(HttpStatus.NOT_FOUND);
				}
				
//			case "lastName":
//				List<Customer> results =service.findAllByLastName(searchValue);
//				if(results!=null && results.size()!=0){
//					
//					resp=new ResponseEntity<>(results,HttpStatus.OK);}
//				else {
//					resp=new ResponseEntity<>(HttpStatus.NOT_FOUND);}
//				break;
//				
//				default:
//					resp= new ResponseEntity<>(HttpStatus.BAD_REQUEST);
//					break;	

		return resp;
	}

	@PostMapping
	public ResponseEntity<Enquiry> addEnquiry(@RequestBody Enquiry enquiry) {
		ResponseEntity<Enquiry> resp = null;

		
		if (resp == null) {
			Enquiry c = service.addEnquiry(enquiry);
			if (c == null)
				resp = new ResponseEntity<Enquiry>(HttpStatus.BAD_REQUEST);
			else
				resp = new ResponseEntity<Enquiry>(c, HttpStatus.OK);
		}
		return resp;
	}

	

//	@DeleteMapping("/{id}")	
//	public ResponseEntity<Void> deleteCustomerAction(@PathVariable("id") long CustomerId) 
//	{		
//		ResponseEntity<Void> resp = null;		
//	boolean isDeleted = service.deleteCustomer(CustomerId);		
//	if (!isDeleted)			
//		resp = new ResponseEntity<>(HttpStatus.NOT_FOUND);		
//	else			
//		resp = new ResponseEntity<>(HttpStatus.OK);		
//	return resp;
//	}
	
}
